
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
# define PI           3.14159265358979323846
GLfloat i = 0.0f;
GLfloat t = 0.0f;
GLfloat m = 0.0f;
GLfloat q = 0.0f;

void Idle()
{
    glutPostRedisplay();//// marks the current window as needing to be redisplayed
}

void display1() {
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    glLineWidth(2);



glBegin(GL_QUADS);//1st
glColor3ub(128, 204, 255);
glVertex2f(1.0f,0.5f);
glVertex2f(1.0f,1.0f);
glVertex2f(-1.0f,1.0f);
glVertex2f(-1.0f,0.5f);
glEnd();

glBegin(GL_QUADS);//2nd
glColor3ub(153, 214, 255);
glVertex2f(1.0f,0.5f);
glVertex2f(-1.0f,0.5f);
glVertex2f(-1.0f,-0.3f);
glVertex2f(1.0f,-0.3f);
glEnd();

glBegin(GL_QUADS);//3rd
glColor3ub(77,75,75);
glVertex2f(1.0f,-0.3f);
glVertex2f(-1.0f,-0.3f);
glVertex2f(-1.0f,-0.6f);
glVertex2f(1.0f,-0.6f);
glEnd();

glBegin(GL_QUADS);//4th
glColor3ub(59,58,57);
glVertex2f(1.0f,-0.6f);
glVertex2f(-1.0f,-0.6f);
glVertex2f(-1.0f,-1.0f);
glVertex2f(1.0f,-1.0f);
glEnd();




	int i;//sun
    glColor3ub(255,255,0);
	GLfloat x=.6f; GLfloat y=.6f; GLfloat radius =.2f;
	int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();


	glBegin(GL_QUADS);//1st building

glColor3ub(26,26,255);
glVertex2f(0.4f,-0.3f);
glVertex2f(0.4f,0.0f);
glVertex2f(-0.1f,0.0f);
glVertex2f(-0.1f,-0.3f);
glEnd();

glBegin(GL_QUADS);//1st building white color

glColor3ub(255,136,77);
glVertex2f(0.4f,-0.3f);
glVertex2f(0.4f,0.0f);
glVertex2f(0.34f,0.0f);
glVertex2f(0.34f,-0.3f);
glEnd();

glBegin(GL_QUADS);//1st building white color

glColor3ub(255,255,255);
glVertex2f(0.15f,-0.3f);
glVertex2f(0.15f,0.0f);
glVertex2f(0.09f,0.0f);
glVertex2f(0.09f,-0.3f);
glEnd();

glBegin(GL_QUADS);//1st building white color

glColor3ub(255,136,77);
glVertex2f(-0.1f,-0.3f);
glVertex2f(-0.1f,0.0f);
glVertex2f(-0.07f,0.0f);
glVertex2f(-0.07f,-0.3f);
glEnd();

glBegin(GL_QUADS);//1st building white color

glColor3ub(255,136,77);
glVertex2f(0.4f,-0.03f);
glVertex2f(0.4f,-0.0f);
glVertex2f(-0.1f,-0.0f);
glVertex2f(-0.1f,-0.03f);
glEnd();

glBegin(GL_QUADS);//1st building white color

glColor3ub(255,255,255);
glVertex2f(0.34f,-0.13f);
glVertex2f(0.34f,-0.1f);
glVertex2f(-0.07f,-0.1f);
glVertex2f(-0.07f,-0.13f);
glEnd();

glBegin(GL_QUADS);//1st building white color

glColor3ub(255,255,255);
glVertex2f(0.34f,-0.23f);
glVertex2f(0.34f,-0.2f);
glVertex2f(-0.07f,-0.2f);
glVertex2f(-0.07f,-0.23f);
glEnd();



glBegin(GL_QUADS);//2nd building
glColor3ub(80, 191, 191);
glVertex2f(-0.1f,0.2f);
glVertex2f(-0.5f,0.2f);
glVertex2f(-0.5f,-0.3f);
glVertex2f(-0.1f,-0.3f);
glEnd();

glBegin(GL_QUADS);//2nd building white color
glColor3ub(255,255,255);
glVertex2f(-0.13f,0.1f);
glVertex2f(-0.2f,0.1f);
glVertex2f(-0.2f,-0.05f);
glVertex2f(-0.13f,-0.05f);
glEnd();

glBegin(GL_QUADS);//2nd building white color
glColor3ub(255,255,255);
glVertex2f(-0.13f,-0.1f);
glVertex2f(-0.2f,-0.1f);
glVertex2f(-0.2f,-0.25f);
glVertex2f(-0.13f,-0.25f);
glEnd();

glBegin(GL_QUADS);//2nd building white color
glColor3ub(255,255,255);
glVertex2f(-0.35f,0.1f);
glVertex2f(-0.45f,0.1f);
glVertex2f(-0.45f,-0.05f);
glVertex2f(-0.35f,-0.05f);
glEnd();

glBegin(GL_QUADS);//2nd building white color
glColor3ub(255,255,255);
glVertex2f(-0.35f,-0.1f);
glVertex2f(-0.45f,-0.1f);
glVertex2f(-0.45f,-0.25f);
glVertex2f(-0.35f,-0.25f);
glEnd();



glBegin(GL_QUADS);//3rd building border
glColor3ub(184, 123, 18);
glVertex2f(-0.5f,0.3f);
glVertex2f(-0.8f,0.3f);
glVertex2f(-0.8f,-0.3f);
glVertex2f(-0.5f,-0.3f);
glEnd();

glBegin(GL_QUADS);//3rd building
glColor3ub(255,255,255);
glVertex2f(-0.52f,0.28f);
glVertex2f(-0.78f,0.28f);
glVertex2f(-0.78f,-0.28f);
glVertex2f(-0.52f,-0.28f);
glEnd();

glBegin(GL_QUADS);//3rd building blue
glColor3ub(71, 191, 255);
glVertex2f(-0.54f,0.26f);
glVertex2f(-0.62f,0.26f);
glVertex2f(-0.62f,0.13f);
glVertex2f(-0.54f,0.13f);
glEnd();

glBegin(GL_QUADS);//3rd building blue
glColor3ub(71, 191, 255);
glVertex2f(-0.54f,0.07f);
glVertex2f(-0.62f,0.07f);
glVertex2f(-0.62f,-0.05f);
glVertex2f(-0.54f,-0.05f);
glEnd();

glBegin(GL_QUADS);//3rd building blue
glColor3ub(71, 191, 255);
glVertex2f(-0.66f,0.26f);
glVertex2f(-0.74f,0.26f);
glVertex2f(-0.74f,0.13f);
glVertex2f(-0.66f,0.13f);
glEnd();

glBegin(GL_QUADS);//3rd building blue
glColor3ub(71, 191, 255);
glVertex2f(-0.66f,0.07f);
glVertex2f(-0.74f,0.07f);
glVertex2f(-0.74f,-0.05f);
glVertex2f(-0.66f,-0.05f);
glEnd();

glBegin(GL_QUADS);//3rd building blue
glColor3ub(71, 191, 255);
glVertex2f(-0.54f,-0.1f);
glVertex2f(-0.62f,-0.1f);
glVertex2f(-0.62f,-0.25f);
glVertex2f(-0.54f,-0.25f);
glEnd();

glBegin(GL_QUADS);//3rd building blue
glColor3ub(71, 191, 255);
glVertex2f(-0.66f,-0.1f);
glVertex2f(-0.74f,-0.1f);
glVertex2f(-0.74f,-0.25f);
glVertex2f(-0.66f,-0.25f);
glEnd();

glBegin(GL_QUADS);//tree
glColor3ub(245, 183, 69);
glVertex2f(-0.88f,-0.2f);
glVertex2f(-0.88f,-0.3f);
glVertex2f(-0.91f,-0.3f);
glVertex2f(-0.91f,-0.2f);
glEnd();

glBegin(GL_TRIANGLES);//tree leaf
glColor3ub(50, 133, 61);
glVertex2f(-0.895f,-0.1f);
glVertex2f(-0.99f,-0.2f);
glVertex2f(-0.8f,-0.2f);
glEnd();

glBegin(GL_TRIANGLES);//tree leaf
glColor3ub(50, 133, 61);
glVertex2f(-0.895f,0.0f);
glVertex2f(-0.96f,-0.2f);
glVertex2f(-0.83f,-0.2f);
glEnd();

glBegin(GL_QUADS);//tower pillar
glColor3ub(255,136,77);
glVertex2f(-0.2f,-0.3f);
glVertex2f(-0.2f,0.4f);
glVertex2f(-0.3f,0.4f);
glVertex2f(-0.3f,-0.3f);
glEnd();

glBegin(GL_QUADS);//tower pillar blue
glColor3ub(148, 161, 224);
glVertex2f(-0.2f,0.35f);
glVertex2f(-0.2f,0.32f);
glVertex2f(-0.3f,0.32f);
glVertex2f(-0.3f,0.35f);
glEnd();

glBegin(GL_QUADS);//tower pillar blue
glColor3ub(148, 161, 224);
glVertex2f(-0.2f,0.3f);
glVertex2f(-0.2f,0.27f);
glVertex2f(-0.3f,0.27f);
glVertex2f(-0.3f,0.3f);
glEnd();


glBegin(GL_QUADS);//tower 1st floor
glColor3ub(255,102,102);
glVertex2f(-0.17f,0.4f);
glVertex2f(-0.15f,0.46f);
glVertex2f(-0.35f,0.46f);
glVertex2f(-0.33f,0.4f);
glEnd();

glBegin(GL_QUADS);//tower 2nd floor
glColor3ub(26,26,255);
glVertex2f(-0.15f,0.46f);
glVertex2f(-0.14f,0.48f);
glVertex2f(-0.36f,0.48f);
glVertex2f(-0.35f,0.46f);
glEnd();

glBegin(GL_QUADS);//tower 3nd floor
glColor3ub(255,0,255);
glVertex2f(-0.14f,0.48f);
glVertex2f(-0.13f,0.52f);
glVertex2f(-0.37f,0.52f);
glVertex2f(-0.36f,0.48f);
glEnd();


glBegin(GL_QUADS);//tower 4nd floor
glColor3ub(28,148,60);
glVertex2f(-0.13f,0.52f);
glVertex2f(-0.12f,0.54f);
glVertex2f(-0.38f,0.54f);
glVertex2f(-0.37f,0.52f);
glEnd();

glBegin(GL_QUADS);//tower 5th floor
glColor3ub(23,25,176);
glVertex2f(-0.23f,0.54f);
glVertex2f(-0.23f,0.56f);
glVertex2f(-0.27f,0.56f);
glVertex2f(-0.27f,0.54f);
glEnd();

glBegin(GL_QUADS);//tower antenna
glColor3ub(22,22,26);
glVertex2f(-0.248f,0.56f);
glVertex2f(-0.248f,0.65f);
glVertex2f(-0.255f,0.65f);
glVertex2f(-0.255f,0.56f);
glEnd();

glBegin(GL_QUADS);//road white line
glColor3ub(255,255,255);
glVertex2f(0.4f,-0.62f);
glVertex2f(0.4f,-0.58f);
glVertex2f(0.25f,-0.58f);
glVertex2f(0.25f,-0.62f);
glEnd();

glBegin(GL_QUADS);//road white line
glColor3ub(255,255,255);
glVertex2f(0.15f,-0.62f);
glVertex2f(0.15f,-0.58f);
glVertex2f(0.01f,-0.58f);
glVertex2f(0.01f,-0.62f);
glEnd();

glBegin(GL_QUADS);//road white line
glColor3ub(255,255,255);
glVertex2f(-0.15f,-0.62f);
glVertex2f(-0.15f,-0.58f);
glVertex2f(-0.25f,-0.58f);
glVertex2f(-0.25f,-0.62f);
glEnd();

glBegin(GL_QUADS);//road white line
glColor3ub(255,255,255);
glVertex2f(0.66f,-0.62f);
glVertex2f(0.66f,-0.58f);
glVertex2f(0.5f,-0.58f);
glVertex2f(0.5f,-0.62f);
glEnd();

glBegin(GL_QUADS);//road white line
glColor3ub(255,255,255);
glVertex2f(0.89f,-0.62f);
glVertex2f(0.89f,-0.58f);
glVertex2f(0.77f,-0.58f);
glVertex2f(0.77f,-0.62f);
glEnd();


glBegin(GL_QUADS);//road white line
glColor3ub(255,255,255);
glVertex2f(-0.35f,-0.62f);
glVertex2f(-0.35f,-0.58f);
glVertex2f(-0.48f,-0.58f);
glVertex2f(-0.48f,-0.62f);
glEnd();

glBegin(GL_QUADS);//road white line
glColor3ub(255,255,255);
glVertex2f(-0.55f,-0.62f);
glVertex2f(-0.55f,-0.58f);
glVertex2f(-0.68f,-0.58f);
glVertex2f(-0.68f,-0.62f);
glEnd();



glBegin(GL_POLYGON);//plane
glColor3ub(145, 194, 150);
glVertex2f(-0.30f,-0.5f);
glVertex2f(-0.90f,-0.5f);
glVertex2f(-0.9f,-0.58f);
glVertex2f(-0.7f,-0.65f);
glVertex2f(-0.3f,-0.65f);
glVertex2f(-0.15f,-0.65f);

glEnd();

glBegin(GL_LINES);//black line
glColor3ub(10,10,10);
glVertex2f(-0.22f,-0.62f);
glVertex2f(-0.7f,-0.62f);
glEnd();

glBegin(GL_LINES);//black line back
glColor3ub(10,10,10);
glVertex2f(-0.87f,-0.5f);
glVertex2f(-0.869f,-0.6f);
glEnd();

glBegin(GL_QUADS);//window
glColor3ub(255,255,255);
glVertex2f(-0.66f,-0.52f);
glVertex2f(-0.7f,-0.52f);
glVertex2f(-0.7f,-0.58f);
glVertex2f(-0.66f,-0.58f);
glEnd();

glBegin(GL_QUADS);//window
glColor3ub(255,255,255);
glVertex2f(-0.59f,-0.52f);
glVertex2f(-0.64f,-0.52f);
glVertex2f(-0.64f,-0.58f);
glVertex2f(-0.59f,-0.58f);
glEnd();

glBegin(GL_QUADS);//window
glColor3ub(255,255,255);
glVertex2f(-0.52f,-0.52f);
glVertex2f(-0.57f,-0.52f);
glVertex2f(-0.57f,-0.58f);
glVertex2f(-0.52f,-0.58f);
glEnd();

glBegin(GL_QUADS);//window
glColor3ub(255,255,255);
glVertex2f(-0.46f,-0.52f);
glVertex2f(-0.5f,-0.52f);
glVertex2f(-0.5f,-0.58f);
glVertex2f(-0.46f,-0.58f);
glEnd();

glBegin(GL_QUADS);//window
glColor3ub(255,255,255);
glVertex2f(-0.39f,-0.52f);
glVertex2f(-0.44f,-0.52f);
glVertex2f(-0.44f,-0.58f);
glVertex2f(-0.39f,-0.58f);
glEnd();

glBegin(GL_TRIANGLES);//font glass
glColor3ub(115, 117, 115);
glVertex2f(-0.21f,-0.6f);
glVertex2f(-0.3f,-0.52f);
glVertex2f(-0.3f,-0.6f);
glEnd();





int j;//airplane tire
    glColor3ub(255,255,255);
	GLfloat x1=-.32f; GLfloat y1=-.7f; GLfloat radius1 =0.02f;
	int triangleAmount1 = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi1 = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x1, y1); // center of circle
		for(j = 0; j <= triangleAmount1;j++) {
			glVertex2f(
		            x1 + (radius1 * cos( j*  twicePi1 / triangleAmount1)),
			    y1 + (radius1 * sin(j * twicePi1 / triangleAmount1))
			);
		}
	glEnd();

	int k;//airplane tire
    glColor3ub(255,255,255);
	GLfloat x2=-.68f; GLfloat y2=-.7f; GLfloat radius2 =.02f;
	int triangleAmount2 = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi2 = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x2, y2); // center of circle
		for(k = 0; k <= triangleAmount2;k++) {
			glVertex2f(
		            x2 + (radius2 * cos( k*  twicePi2 / triangleAmount2)),
			    y2 + (radius2 * sin(k * twicePi2 / triangleAmount2))
			);
		}
	glEnd();




glBegin(GL_LINES);
glColor3ub(255,255,255);
glVertex2f(-0.32f,-0.7f);
glVertex2f(-0.32f,-0.65f);
glEnd();

glBegin(GL_LINES);
glColor3ub(255,255,255);
glVertex2f(-0.68f,-0.7f);
glVertex2f(-0.68f,-0.65f);
glEnd();



	glBegin(GL_QUADS);//plane back wings
glColor3ub(80, 110, 85);
glVertex2f(-0.84f,-0.5f);
glVertex2f(-0.88f,-0.42f);
glVertex2f(-0.88f,-0.42f);
glVertex2f(-0.89f,-0.5f);
glEnd();

glBegin(GL_QUADS);//plane side back wings
glColor3ub(80, 110, 85);
glVertex2f(-0.81f,-0.57f);
glVertex2f(-0.86f,-0.57f);
glVertex2f(-0.89f,-0.62f);
glVertex2f(-0.87f,-0.62f);
glEnd();

glBegin(GL_QUADS);//plane upper wings
glColor3ub(80, 110, 85);
glVertex2f(-0.5f,-0.5f);
glVertex2f(-0.56f,-0.44f);
glVertex2f(-0.62f,-0.44f);
glVertex2f(-0.59f,-0.5f);
glEnd();

glBegin(GL_QUADS);//plane lower wings
glColor3ub(80, 110, 85);
glVertex2f(-0.48f,-0.6f);
glVertex2f(-0.61f,-0.6f);
glVertex2f(-0.68f,-0.72f);
glVertex2f(-0.57f,-0.71f);
glEnd();

glBegin(GL_QUADS);//windmill body
glColor3ub(255,255,255);
glVertex2f(0.709f,-0.3f);
glVertex2f(0.709f,0.098f);
glVertex2f(0.692f,0.098f);
glVertex2f(0.692f,-0.3f);
glEnd();

int l;//wind turbine
    glColor3ub(255,255,255);
	GLfloat x3=0.7f; GLfloat y3=0.1f; GLfloat radius3 =.02f;
	int triangleAmount3 = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi3 = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x3, y3); // center of circle
		for(l = 0; l <= triangleAmount3;l++) {
			glVertex2f(
		            x3 + (radius3 * cos( l*  twicePi3 / triangleAmount3)),
			    y3 + (radius3 * sin(l * twicePi3 / triangleAmount3))
			);
		}
	glEnd();


	        glPushMatrix(); //glPushMatrix copies the top matrix and pushes it onto the stack,
	        glTranslated(0.7,0.1,0);
glRotatef(i,0.0,0.0,0.1);//i=how many degree you want to rotate around an axis

   glBegin(GL_TRIANGLES);//windmill fan
glColor3ub(255,255,255);
glVertex2f(0.0f,0.0f);
glVertex2f(0.23f,0.1f);
glVertex2f(0.1f,0.2f);
glEnd();


glBegin(GL_TRIANGLES);//windmill fan
glColor3ub(255,255,255);
glVertex2f(0.0f,0.0f);
glVertex2f(-0.23f,0.05f);
glVertex2f(-0.1f,0.15f);
glEnd();

glBegin(GL_TRIANGLES);//windmill fan
glColor3ub(255,255,255);
glVertex2f(0.0f,0.0f);
glVertex2f(0.0f,-0.25f);
glVertex2f(-0.15f,-0.15f);
glEnd();



    glPopMatrix();//glPopMatrix pops the top matrix off the stack
    i+=0.1f;//i=i+.1=.2

glTranslated(0,0,0);

glBegin(GL_QUADS);//clock body
glColor3ub(66, 67, 77);
glVertex2f(0.40f,0.0f);
glVertex2f(0.40f,0.3f);
glVertex2f(-0.10f,0.3f);
glVertex2f(-0.1f,0.0f);
glEnd();

glBegin(GL_QUADS);//clock body
glColor3ub(39, 50, 161);
glVertex2f(0.38f,0.02f);
glVertex2f(0.38f,0.28f);
glVertex2f(-0.08f,0.28f);
glVertex2f(-0.08f,0.02f);
glEnd();

     glPushMatrix(); //glPushMatrix copies the top matrix and pushes it onto the stack,
    glTranslated(0.16,0.15,0);
glRotatef(q,0.0,0.0,-0.1);//i=how many degree you want to rotate around an axis

glBegin(GL_LINES);
glColor3ub(255,255,255);
glVertex2f(0.0f,0.0f);
glVertex2f(0.0f,0.1f);
glEnd();

glPopMatrix();//glPopMatrix pops the top matrix off the stack
    q+=0.01f;//i=i+.1=.2

glPushMatrix(); //glPushMatrix copies the top matrix and pushes it onto the stack,
	        glTranslated(0.16,0.15,0);
glRotatef(m,0.0,0.0,-0.1);//i=how many degree you want to rotate around an axis


glBegin(GL_LINES);
glColor3ub(255,255,255);
glVertex2f(0.0f,0.0f);
glVertex2f(0.08f,0.02f);
glEnd();

glPopMatrix();//glPopMatrix pops the top matrix off the stack
    m+=0.02f;//i=i+.1=.2

    glPushMatrix(); //glPushMatrix copies the top matrix and pushes it onto the stack,
	        glTranslated(0.16,0.15,0);
glRotatef(t,0.0,0.0,-0.1);//i=how many degree you want to rotate around an axis


glBegin(GL_LINES);
glColor3ub(255,255,255);
glVertex2f(0.0f,0.0f);
glVertex2f(-0.1f,-0.1f);
glEnd();

 glPopMatrix();//glPopMatrix pops the top matrix off the stack
    t+=0.03f;//i=i+.1=.2



	glFlush();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("Test");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display1);
	    glutIdleFunc(Idle);//glutIdleFunc sets the global idle callback to be func so a GLUT program can perform background processing tasks or continuous animation when window system events are not being received.
	glutMainLoop();
	return 0;
}

