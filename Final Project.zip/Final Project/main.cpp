#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
# define PI           3.14159265358979323846

void display1() {
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

 glBegin(GL_QUADS);//green
glColor3ub(76, 166, 73);
glVertex2f(-1.0f,0.0f);
glVertex2f(-1.0f,-0.5f);
glVertex2f(10.f,-0.5f);
glVertex2f(1.0f,0.0f);
glEnd();

glBegin(GL_QUADS);//fountain left
glColor3ub(198, 140, 83);
glVertex2f(-0.55f,-0.2f);
glVertex2f(-0.57f,-0.32f);
glVertex2f(-0.43f,-0.32f);
glVertex2f(-0.45f,-0.2f);
glEnd();

glBegin(GL_QUADS);//fountain blue
glColor3ub(102, 194, 255);
glVertex2f(-0.54f,-0.22f);
glVertex2f(-0.56f,-0.31f);
glVertex2f(-0.44f,-0.31f);
glVertex2f(-0.46f,-0.22f);
glEnd();

glBegin(GL_QUADS);//fountain
glColor3ub(0, 0, 0);
glVertex2f(-0.505f,-0.26f);
glVertex2f(-0.51f,-0.29f);
glVertex2f(-0.49f,-0.29f);
glVertex2f(-0.495f,-0.26f);
glEnd();

glBegin(GL_TRIANGLES);//fountain water
glColor3ub(204, 255, 255);
glVertex2f(-0.538f,-0.23f);
glVertex2f(-0.5f,-0.26f);
glVertex2f(-0.462f,-0.23f);
glEnd();

glBegin(GL_TRIANGLES);//fountain water
glColor3ub(204, 255, 255);
glVertex2f(-0.54f,-0.214f);
glVertex2f(-0.5f,-0.24f);
glVertex2f(-0.46f,-0.214f);
glEnd();

glBegin(GL_TRIANGLES);//fountain water
glColor3ub(204, 255, 255);
glVertex2f(-0.5f,-0.195f);
glVertex2f(-0.51f,-0.214f);
glVertex2f(-0.49f,-0.214f);
glEnd();
//
glBegin(GL_QUADS);//fountain right
glColor3ub(198, 140, 83);
glVertex2f(0.55f,-0.2f);
glVertex2f(0.57f,-0.32f);
glVertex2f(0.43f,-0.32f);
glVertex2f(0.45f,-0.2f);
glEnd();

glBegin(GL_QUADS);//fountain blue
glColor3ub(102, 194, 255);
glVertex2f(0.54f,-0.22f);
glVertex2f(0.56f,-0.31f);
glVertex2f(0.44f,-0.31f);
glVertex2f(0.46f,-0.22f);
glEnd();

glBegin(GL_QUADS);//fountain
glColor3ub(0, 0, 0);
glVertex2f(0.505f,-0.26f);
glVertex2f(0.51f,-0.29f);
glVertex2f(0.49f,-0.29f);
glVertex2f(0.495f,-0.26f);
glEnd();

glBegin(GL_TRIANGLES);//fountain water
glColor3ub(204, 255, 255);
glVertex2f(0.538f,-0.23f);
glVertex2f(0.5f,-0.26f);
glVertex2f(0.462f,-0.23f);
glEnd();

glBegin(GL_TRIANGLES);//fountain water
glColor3ub(204, 255, 255);
glVertex2f(0.54f,-0.214f);
glVertex2f(0.5f,-0.24f);
glVertex2f(0.46f,-0.214f);
glEnd();

glBegin(GL_TRIANGLES);//fountain water
glColor3ub(204, 255, 255);
glVertex2f(0.5f,-0.195f);
glVertex2f(0.51f,-0.214f);
glVertex2f(0.49f,-0.214f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(0, 0, 0);
glVertex2f(-0.97f,-0.25f);
glVertex2f(-.97f,-0.28f);
glVertex2f(-0.7f,-0.28f);
glVertex2f(-0.7f,-0.25f);
glEnd();


glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.97f,0.05f);
glVertex2f(-.97f,0.0f);
glVertex2f(-0.68f,0.0f);
glVertex2f(-0.68f,0.05f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-.7f,0.00f);
glVertex2f(-0.7f,-0.28f);
glVertex2f(-0.68f,-0.17f);
glVertex2f(-0.68f,0.07f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.65f,0.1f);
glVertex2f(-0.65f,0.3f);
glVertex2f(-0.28f,0.3f);
glVertex2f(-0.28f,0.1f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-.68f,0.1f);
glVertex2f(-0.7f,-0.17);
glVertex2f(-0.2f,-0.17f);
glVertex2f(-0.2f,0.1f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.942f,0.3f);
glVertex2f(-0.942f,0.05f);
glVertex2f(-0.65f,0.05f);
glVertex2f(-0.65f,0.3f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.97f,0.05f);
glVertex2f(-.97f,0.0f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-.97f,0.0f);
glVertex2f(-0.68f,0.0f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.68f,0.0f);
glVertex2f(-0.68f,0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.97f,0.05f);
glVertex2f(-0.68f,0.05f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.95f,0.0f);
glVertex2f(-.95f,-0.25f);
glVertex2f(-0.7f,-0.25f);
glVertex2f(-0.7f,0.0f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,0.0f);
glVertex2f(-.95f,-0.25f);
glVertex2f(-0.7f,-0.25f);
glVertex2f(-0.7f,0.0f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,0.0f);
glVertex2f(-.95f,-0.25f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-.95f,-0.25f);
glVertex2f(-0.7f,-0.25f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.7f,-0.25f);
glVertex2f(-0.7f,0.0f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,0.0f);
glVertex2f(-0.7f,0.0f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.93f,0.0f);
glVertex2f(-.93f,-0.25f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.72f,-0.25f);
glVertex2f(-0.72f,0.0f);
glEnd();


glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.84f,0.0f);
glVertex2f(-.84f,-0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.84f,-0.05f);
glVertex2f(-.82f,-0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.82f,0.0f);
glVertex2f(-.82f,-0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.84f,-0.2f);
glVertex2f(-.84f,-0.25f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.84f,-0.2f);
glVertex2f(-.82f,-0.2f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.82f,-0.2f);
glVertex2f(-.82f,-0.25f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.835f,-0.05f);
glVertex2f(-.835f,-0.2f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.825f,-0.05f);
glVertex2f(-.825f,-0.2f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(0, 0,0);
glVertex2f(-0.68f,-0.17f);
glVertex2f(-.68f,-0.19f);
glVertex2f(-0.25f,-0.19f);
glVertex2f(-0.25f,-0.17f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(0,0,0);
glVertex2f(-0.68f,-0.17f);
glVertex2f(-.68f,-0.19f);
glVertex2f(-0.7f,-0.28f);
glVertex2f(-0.7f,-0.25f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.68f,0.1f);
glVertex2f(-.68f,0.07f);
glVertex2f(-0.28f,0.07f);
glVertex2f(-0.28f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.68f,0.1f);
glVertex2f(-.68f,0.07f);
glVertex2f(-0.28f,0.07f);
glVertex2f(-0.28f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.68f,0.1f);
glVertex2f(-.68f,0.07f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-.68f,0.07f);
glVertex2f(-0.28f,0.07f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.28f,0.07f);
glVertex2f(-0.28f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.68f,0.1f);
glVertex2f(-0.28f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.68f,0.07f);
glVertex2f(-.68f,-0.17f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.665f,0.07f);
glVertex2f(-.665f,-0.17f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.58f,0.07f);
glVertex2f(-.58f,0.04f);
glVertex2f(-.56f,0.04f);
glVertex2f(-.56f,0.07f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.58f,0.07f);
glVertex2f(-.58f,0.04f);
glVertex2f(-.56f,0.04f);
glVertex2f(-.56f,0.07f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.58f,0.07f);
glVertex2f(-.58f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-.58f,0.04f);
glVertex2f(-.56f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-.56f,0.04f);
glVertex2f(-.56f,0.07f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.58f,0.07f);
glVertex2f(-.56f,0.07f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.575f,0.04f);
glVertex2f(-.575f,-0.14f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.565f,0.04f);
glVertex2f(-.565f,-0.14f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.58f,-0.14f);
glVertex2f(-.58f,-0.17f);
glVertex2f(-.56f,-0.17f);
glVertex2f(-.56f,-0.14f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.58f,-0.14f);
glVertex2f(-.58f,-0.17f);
glVertex2f(-.56f,-0.17f);
glVertex2f(-.56f,-0.14f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.58f,-0.14f);
glVertex2f(-.58f,-0.17f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-.58f,-0.17f);
glVertex2f(-.56f,-0.17f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-.56f,-0.17f);
glVertex2f(-.56f,-0.14f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.58f,-0.14f);
glVertex2f(-.56f,-0.14f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.3f,0.07f);
glVertex2f(-0.3f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.32f,0.07f);
glVertex2f(-0.32f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.32f,0.04f);
glVertex2f(-0.3f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.3f,-0.14f);
glVertex2f(-0.3f,-0.17f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.32f,-0.14f);
glVertex2f(-0.32f,-0.17f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.32f,-0.14f);
glVertex2f(-0.3f,-0.14f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.315f,-0.14f);
glVertex2f(-0.315f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.305f,-0.14f);
glVertex2f(-0.305f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.43f,0.07f);
glVertex2f(-0.43f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.45f,0.07f);
glVertex2f(-0.45f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.45f,0.04f);
glVertex2f(-0.43f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.43f,-0.14f);
glVertex2f(-0.43f,-0.17f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.45f,-0.14f);
glVertex2f(-0.45f,-0.17f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.45f,-0.14f);
glVertex2f(-0.43f,-0.14f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.435f,-0.14f);
glVertex2f(-0.435f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.445f,-0.14f);
glVertex2f(-0.445f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,-0.03f);
glVertex2f(-0.93f,-0.03f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,-0.06f);
glVertex2f(-0.93f,-0.06f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,-0.09f);
glVertex2f(-0.93f,-0.09f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,-0.12f);
glVertex2f(-0.93f,-0.12f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,-0.15f);
glVertex2f(-0.93f,-0.15f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,-0.18f);
glVertex2f(-0.93f,-0.18f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,-0.21f);
glVertex2f(-0.93f,-0.21f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.7f,-0.03f);
glVertex2f(-0.72f,-0.03f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.7f,-0.06f);
glVertex2f(-0.72f,-0.06f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.7f,-0.09f);
glVertex2f(-0.72f,-0.09f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.7f,-0.12f);
glVertex2f(-0.72f,-0.12f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.7f,-0.15f);
glVertex2f(-0.72f,-0.15f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.7f,-0.18f);
glVertex2f(-0.72f,-0.18f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.7f,-0.21f);
glVertex2f(-0.72f,-0.21f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.28f,0.4f);
glVertex2f(-0.28f,0.1f);
glVertex2f(-0.24f,0.1f);
glVertex2f(-0.24f,0.4f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.28f,0.1f);
glVertex2f(0.28f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.28f,0.1f);
glVertex2f(-0.28f,0.4f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.27f,0.1f);
glVertex2f(-0.27f,0.38f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.25f,0.1f);
glVertex2f(-0.25f,0.38f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.24f,0.4f);
glVertex2f(-0.28f,0.4f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.25f,0.38f);
glVertex2f(-0.27f,0.38f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.98f,0.33f);
glVertex2f(-0.98f,0.3f);
glVertex2f(-0.28f,0.3f);
glVertex2f(-0.28f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.98f,0.33f);
glVertex2f(-0.98f,0.3f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.98f,0.3f);
glVertex2f(-0.28f,0.3f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.28f,0.3f);
glVertex2f(-0.28f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.98f,0.33f);
glVertex2f(-0.28f,0.33f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.96f,0.3f);
glVertex2f(-0.96f,0.27f);
glVertex2f(-0.65f,0.27f);
glVertex2f(-0.65f,0.3f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.96f,0.3f);
glVertex2f(-0.96f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.96f,0.27f);
glVertex2f(-0.65f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.65f,0.27f);
glVertex2f(-0.65f,0.3f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.96f,0.3f);
glVertex2f(-0.65f,0.3f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.65f,0.3f);
glVertex2f(-0.65f,0.1f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.95f,0.27f);
glVertex2f(-0.95f,0.24f);
glVertex2f(-0.92f,0.24f);
glVertex2f(-0.92f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,0.27f);
glVertex2f(-0.95f,0.24f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,0.24f);
glVertex2f(-0.92f,0.24f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.92f,0.24f);
glVertex2f(-0.92f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,0.27f);
glVertex2f(-0.92f,0.27f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.95f,0.08f);
glVertex2f(-0.95f,0.05f);
glVertex2f(-0.92f,0.05f);
glVertex2f(-0.92f,0.08f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,0.08f);
glVertex2f(-0.95f,0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,0.05f);
glVertex2f(-0.92f,0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.92f,0.05f);
glVertex2f(-0.92f,0.08f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.95f,0.08f);
glVertex2f(-0.92f,0.08f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.942f,0.24f);
glVertex2f(-0.942f,0.08f);
glVertex2f(-0.928f,0.08f);
glVertex2f(-0.928f,0.24f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.942f,0.24f);
glVertex2f(-0.942f,0.08f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.928f,0.08f);
glVertex2f(-0.928f,0.24f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.78f,0.08f);
glVertex2f(-0.78f,0.05f);
glVertex2f(-0.81f,0.05f);
glVertex2f(-0.81f,0.08f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.78f,0.08f);
glVertex2f(-0.78f,0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.78f,0.05f);
glVertex2f(-0.81f,0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.81f,0.05f);
glVertex2f(-0.81f,0.08f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.78f,0.08f);
glVertex2f(-0.81f,0.08f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.81f,0.27f);
glVertex2f(-0.81f,0.24f);
glVertex2f(-0.78f,0.24f);
glVertex2f(-0.78f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.81f,0.27f);
glVertex2f(-0.81f,0.24f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.81f,0.24f);
glVertex2f(-0.78f,0.24f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.78f,0.24f);
glVertex2f(-0.78f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.81f,0.27f);
glVertex2f(-0.78f,0.27f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.805f,0.24f);
glVertex2f(-0.805f,0.08f);
glVertex2f(-0.787f,0.08f);
glVertex2f(-0.787f,0.24f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.805f,0.24f);
glVertex2f(-0.805f,0.08f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.787f,0.08f);
glVertex2f(-0.787f,0.24f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.63f,0.3f);
glVertex2f(-0.63f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.6f,0.3f);
glVertex2f(-0.6f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.63f,0.27f);
glVertex2f(-0.6f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.63f,0.13f);
glVertex2f(-0.63f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.6f,0.13f);
glVertex2f(-0.6f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.6f,0.13f);
glVertex2f(-0.63f,0.13f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.625f,0.13f);
glVertex2f(-0.625f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.61f,0.13f);
glVertex2f(-0.61f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.5f,0.3f);
glVertex2f(-0.5f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.47f,0.3f);
glVertex2f(-0.47f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.5f,0.27f);
glVertex2f(-0.47f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.5f,0.13f);
glVertex2f(-0.5f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.47f,0.13f);
glVertex2f(-0.47f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.5f,0.13f);
glVertex2f(-0.47f,0.13f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.495f,0.13f);
glVertex2f(-0.495f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.48f,0.13f);
glVertex2f(-0.48f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.31f,0.3f);
glVertex2f(-0.31f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.34f,0.3f);
glVertex2f(-0.34f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.31f,0.27f);
glVertex2f(-0.34f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.31f,0.1f);
glVertex2f(-0.31f,0.13f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.34f,0.1f);
glVertex2f(-0.34f,0.13f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.31f,0.13f);
glVertex2f(-0.34f,0.13f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.315f,0.27f);
glVertex2f(-0.315f,0.13f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.335f,0.27f);
glVertex2f(-0.335f,0.13f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.96f,0.45f);
glVertex2f(-0.96f,0.33f);
glVertex2f(-0.91f,0.33f);
glVertex2f(-0.91f,0.45f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.96f,0.45f);
glVertex2f(-0.96f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.96f,0.33f);
glVertex2f(-0.91f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.91f,0.33f);
glVertex2f(-0.91f,0.45f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.96f,0.45f);
glVertex2f(-0.91f,0.45f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.7f,0.45f);
glVertex2f(-0.7f,0.33f);
glVertex2f(-0.65f,0.33f);
glVertex2f(-0.65f,0.45f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.7f,0.45f);
glVertex2f(-0.7f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.7f,0.33f);
glVertex2f(-0.65f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.65f,0.33f);
glVertex2f(-0.65f,0.45f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.7f,0.45f);
glVertex2f(-0.65f,0.45f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.91f,0.42f);
glVertex2f(-0.91f,0.33f);
glVertex2f(-0.7f,0.33f);
glVertex2f(-0.7f,0.42f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.91f,0.42f);
glVertex2f(-0.91f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.91f,0.33f);
glVertex2f(-0.7f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.7f,0.33f);
glVertex2f(-0.7f,0.42f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.91f,0.42f);
glVertex2f(-0.7f,0.42f);
glEnd();

glBegin(GL_TRIANGLES);
glColor3ub(255, 172, 117);
glVertex2f(-0.805f,0.5f);
glVertex2f(-0.88f,0.42f);
glVertex2f(-0.73f,0.42f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.805f,0.5f);
glVertex2f(-0.88f,0.42f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.805f,0.5f);
glVertex2f(-0.73f,0.42f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.805f,0.47f);
glVertex2f(-0.85f,0.42f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.805f,0.47f);
glVertex2f(-0.76f,0.42f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.935f,0.48f);
glVertex2f(-0.935f,0.45f);
glEnd();

glBegin(GL_TRIANGLES);//building light
glColor3ub(255, 247, 0);
glVertex2f(-0.935f,0.53f);
glVertex2f(-0.942f,0.48f);
glVertex2f(-0.928f,0.48f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.675f,0.48f);
glVertex2f(-0.675f,0.45f);
glEnd();

glBegin(GL_TRIANGLES);//building light
glColor3ub(255, 247, 0);
glVertex2f(-0.676f,0.53f);
glVertex2f(-0.684f,0.48f);
glVertex2f(-0.669f,0.48f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.65f,0.36f);
glVertex2f(-0.65f,0.33f);
glVertex2f(-0.28f,0.33f);
glVertex2f(-0.28f,0.36f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.65f,0.36f);
glVertex2f(-0.65f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.65f,0.33f);
glVertex2f(-0.28f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.28f,0.33f);
glVertex2f(-0.28f,0.36f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.65f,0.36f);
glVertex2f(-0.28f,0.36f);
glEnd();


glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.95f,0.43f);
glVertex2f(-0.95f,0.35f);
glVertex2f(-0.92f,0.35f);
glVertex2f(-0.92f,0.43f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.69f,0.43f);
glVertex2f(-0.69f,0.35f);
glVertex2f(-0.66f,0.35f);
glVertex2f(-0.66f,0.43f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.88f,0.41f);
glVertex2f(-0.88f,0.34f);
glVertex2f(-0.85f,0.34f);
glVertex2f(-0.85f,0.41f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.82f,0.41f);
glVertex2f(-0.82f,0.34f);
glVertex2f(-0.79f,0.34f);
glVertex2f(-0.79f,0.41f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.76f,0.41f);
glVertex2f(-0.76f,0.34f);
glVertex2f(-0.73f,0.34f);
glVertex2f(-0.73f,0.41f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.9f,0.25f);
glVertex2f(-0.9f,0.23f);
glVertex2f(-0.84f,0.23f);
glVertex2f(-0.84f,0.25f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.89f,0.21f);
glVertex2f(-0.89f,0.13f);
glVertex2f(-0.85f,0.13f);
glVertex2f(-0.85f,0.21f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.76f,0.25f);
glVertex2f(-0.76f,0.23f);
glVertex2f(-0.68f,0.23f);
glVertex2f(-0.68f,0.25f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.74f,0.21f);
glVertex2f(-0.74f,0.13f);
glVertex2f(-0.7f,0.13f);
glVertex2f(-0.7f,0.21f);
glEnd();


glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.9f,-0.1f);
glVertex2f(-0.9f,-0.25f);
glVertex2f(-0.87f,-0.25f);
glVertex2f(-0.87f,-0.1f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.78f,-0.1f);
glVertex2f(-0.78f,-0.25f);
glVertex2f(-0.75f,-0.25f);
glVertex2f(-0.75f,-0.1f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.64f,-0.01f);
glVertex2f(-0.64f,-0.17f);
glVertex2f(-0.61f,-0.17f);
glVertex2f(-0.61f,-0.01f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.52f,-0.01f);
glVertex2f(-0.52f,-0.17f);
glVertex2f(-0.49f,-0.17f);
glVertex2f(-0.49f,-0.01f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.39f,-0.01f);
glVertex2f(-0.39f,-0.17f);
glVertex2f(-0.36f,-0.17f);
glVertex2f(-0.36f,-0.01f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.57f,0.23f);
glVertex2f(-0.57f,0.1f);
glVertex2f(-0.54f,0.1f);
glVertex2f(-0.54f,0.23f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.43f,0.23f);
glVertex2f(-0.43f,0.1f);
glVertex2f(-0.4f,0.1f);
glVertex2f(-0.4f,0.23f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.24f,0.1f);
glVertex2f(0.24f,0.38f);
glVertex2f(-0.24f,0.38f);
glVertex2f(-0.24f,0.1f);
glEnd();
//
glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.125f,0.48f);
glVertex2f(-0.125f,0.38f);
glVertex2f(0.125f,0.38f);
glVertex2f(0.125f,0.48f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.28f,0.4f);
glVertex2f(0.28f,0.1f);
glVertex2f(0.24f,0.1f);
glVertex2f(0.24f,0.4f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.28f,0.1f);
glVertex2f(0.28f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.28f,0.1f);
glVertex2f(0.28f,0.4f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.24f,0.1f);
glVertex2f(0.24f,0.4f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.27f,0.1f);
glVertex2f(0.27f,0.38f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.25f,0.1f);
glVertex2f(0.25f,0.38f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.24f,0.4f);
glVertex2f(0.28f,0.4f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.25f,0.38f);
glVertex2f(0.27f,0.38f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.24f,0.4f);
glVertex2f(-0.24f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.24f,0.38f);
glVertex2f(0.24f,0.38f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.24f,0.36f);
glVertex2f(0.24f,0.36f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.05f,0.25f);
glVertex2f(-0.05f,0.1f);
glVertex2f(0.05f,0.1f);
glVertex2f(0.05f,0.25f);
glEnd();

int i;
    glColor3ub(135, 81, 19);
	GLfloat x=.0f; GLfloat y=.25f; GLfloat radius =.05f;
	int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 1.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	int j;
    glColor3ub(135, 81, 19);
	GLfloat x1=.0f; GLfloat y1=.38f; GLfloat radius1 =.05f;
	int triangleAmount1 = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi1 = 1.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x1, y1); // center of circle
		for(j = 0; j <= triangleAmount1;j++) {
			glVertex2f(
		            x1 + (radius1 * cos(j *  twicePi1 / triangleAmount1)),
			    y1 + (radius1 * sin(j * twicePi1 / triangleAmount1))
			);
		}
	glEnd();

	int k;
    glColor3ub(255, 172, 117);
	GLfloat x2=.0f; GLfloat y2=.5f; GLfloat radius2 =.15f;
	int triangleAmount2 = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi2 = 1.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x2, y2); // center of circle
		for(k = 0; k <= triangleAmount2;k++) {
			glVertex2f(
		            x2 + (radius2 * cos(k *  twicePi2 / triangleAmount2)),
			    y2 + (radius2 * sin(k * twicePi2 / triangleAmount2))
			);
		}
	glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.11f,0.36f);
glVertex2f(-0.11f,0.34f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.14f,0.36f);
glVertex2f(-0.14f,0.34f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.14f,0.34f);
glVertex2f(-0.11f,0.34f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.11f,0.1f);
glVertex2f(-0.11f,0.12f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.14f,0.1f);
glVertex2f(-0.14f,0.12f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.14f,0.12f);
glVertex2f(-0.11f,0.12f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.12f,0.34f);
glVertex2f(-0.12f,0.12f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.13f,0.34f);
glVertex2f(-0.13f,0.12f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.2f,0.25f);
glVertex2f(-0.2f,0.1f);
glVertex2f(-0.17f,0.1f);
glVertex2f(-0.17f,0.25f);
glEnd();



glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.11f,0.36f);
glVertex2f(0.11f,0.34f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.14f,0.36f);
glVertex2f(0.14f,0.34f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.14f,0.34f);
glVertex2f(0.11f,0.34f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.11f,0.1f);
glVertex2f(0.11f,0.12f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.14f,0.1f);
glVertex2f(0.14f,0.12f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.14f,0.12f);
glVertex2f(0.11f,0.12f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.12f,0.34f);
glVertex2f(0.12f,0.12f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.13f,0.34f);
glVertex2f(0.13f,0.12f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.2f,0.25f);
glVertex2f(0.2f,0.1f);
glVertex2f(0.17f,0.1f);
glVertex2f(0.17f,0.25f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.125f,0.38f);
glVertex2f(0.125f,0.48f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.125f,0.38f);
glVertex2f(-0.125f,0.48f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.17f,0.5f);
glVertex2f(-0.17f,0.48f);
glVertex2f(0.17f,0.48f);
glVertex2f(0.17f,0.5f);
glEnd();

glBegin(GL_TRIANGLES);
glColor3ub(135, 81, 19);
glVertex2f(0.0f,0.68f);
glVertex2f(-0.02f,0.645f);
glVertex2f(0.02f,0.645f);
glEnd();

//

glBegin(GL_QUADS);
glColor3ub(0, 0, 0);
glVertex2f(0.97f,-0.25f);
glVertex2f(0.97f,-0.28f);
glVertex2f(0.7f,-0.28f);
glVertex2f(0.7f,-0.25f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.97f,0.05f);
glVertex2f(0.97f,0.0f);
glVertex2f(0.68f,0.0f);
glVertex2f(0.68f,0.05f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.7f,0.00f);
glVertex2f(0.7f,-0.28f);
glVertex2f(0.68f,-0.17f);
glVertex2f(0.68f,0.07f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.65f,0.1f);
glVertex2f(0.65f,0.3f);
glVertex2f(0.28f,0.3f);
glVertex2f(0.28f,0.1f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(.68f,0.1f);
glVertex2f(0.7f,-0.17);
glVertex2f(0.2f,-0.17f);
glVertex2f(0.2f,0.1f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.942f,0.3f);
glVertex2f(0.942f,0.05f);
glVertex2f(0.65f,0.05f);
glVertex2f(0.65f,0.3f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.97f,0.05f);
glVertex2f(0.97f,0.0f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.97f,0.0f);
glVertex2f(0.68f,0.0f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.68f,0.0f);
glVertex2f(0.68f,0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.97f,0.05f);
glVertex2f(0.68f,0.05f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.95f,0.0f);
glVertex2f(0.95f,-0.25f);
glVertex2f(0.7f,-0.25f);
glVertex2f(0.7f,0.0f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,0.0f);
glVertex2f(0.95f,-0.25f);
glVertex2f(0.7f,-0.25f);
glVertex2f(0.7f,0.0f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,0.0f);
glVertex2f(0.95f,-0.25f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(.95f,-0.25f);
glVertex2f(0.7f,-0.25f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.7f,-0.25f);
glVertex2f(0.7f,0.0f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,0.0f);
glVertex2f(0.7f,0.0f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.93f,0.0f);
glVertex2f(0.93f,-0.25f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.72f,-0.25f);
glVertex2f(0.72f,0.0f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.84f,0.0f);
glVertex2f(0.84f,-0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.84f,-0.05f);
glVertex2f(0.82f,-0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.82f,0.0f);
glVertex2f(0.82f,-0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.84f,-0.2f);
glVertex2f(0.84f,-0.25f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.84f,-0.2f);
glVertex2f(0.82f,-0.2f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.82f,-0.2f);
glVertex2f(0.82f,-0.25f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.835f,-0.05f);
glVertex2f(0.835f,-0.2f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.825f,-0.05f);
glVertex2f(0.825f,-0.2f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(0, 0,0);
glVertex2f(0.68f,-0.17f);
glVertex2f(0.68f,-0.19f);
glVertex2f(0.25f,-0.19f);
glVertex2f(0.25f,-0.17f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(0,0,0);
glVertex2f(0.68f,-0.17f);
glVertex2f(0.68f,-0.19f);
glVertex2f(0.7f,-0.28f);
glVertex2f(0.7f,-0.25f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.68f,0.1f);
glVertex2f(0.68f,0.07f);
glVertex2f(0.28f,0.07f);
glVertex2f(0.28f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.68f,0.1f);
glVertex2f(0.68f,0.07f);
glVertex2f(0.28f,0.07f);
glVertex2f(0.28f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.68f,0.1f);
glVertex2f(0.68f,0.07f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.68f,0.07f);
glVertex2f(0.28f,0.07f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.28f,0.07f);
glVertex2f(0.28f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.68f,0.1f);
glVertex2f(0.28f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.68f,0.07f);
glVertex2f(0.68f,-0.17f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.665f,0.07f);
glVertex2f(0.665f,-0.17f);
glEnd();//

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.58f,0.07f);
glVertex2f(0.58f,0.04f);
glVertex2f(0.56f,0.04f);
glVertex2f(0.56f,0.07f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.58f,0.07f);
glVertex2f(0.58f,0.04f);
glVertex2f(0.56f,0.04f);
glVertex2f(0.56f,0.07f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.58f,0.07f);
glVertex2f(0.58f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.58f,0.04f);
glVertex2f(0.56f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.56f,0.04f);
glVertex2f(0.56f,0.07f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.58f,0.07f);
glVertex2f(0.56f,0.07f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.575f,0.04f);
glVertex2f(0.575f,-0.14f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.565f,0.04f);
glVertex2f(0.565f,-0.14f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.58f,-0.14f);
glVertex2f(0.58f,-0.17f);
glVertex2f(0.56f,-0.17f);
glVertex2f(0.56f,-0.14f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.58f,-0.14f);
glVertex2f(0.58f,-0.17f);
glVertex2f(0.56f,-0.17f);
glVertex2f(0.56f,-0.14f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.58f,-0.14f);
glVertex2f(0.58f,-0.17f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(.58f,-0.17f);
glVertex2f(.56f,-0.17f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(.56f,-0.17f);
glVertex2f(.56f,-0.14f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.58f,-0.14f);
glVertex2f(.56f,-0.14f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.3f,0.07f);
glVertex2f(0.3f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.32f,0.07f);
glVertex2f(0.32f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.32f,0.04f);
glVertex2f(0.3f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.3f,-0.14f);
glVertex2f(0.3f,-0.17f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.32f,-0.14f);
glVertex2f(0.32f,-0.17f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.32f,-0.14f);
glVertex2f(0.3f,-0.14f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.315f,-0.14f);
glVertex2f(0.315f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.305f,-0.14f);
glVertex2f(0.305f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.43f,0.07f);
glVertex2f(0.43f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.45f,0.07f);
glVertex2f(0.45f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.45f,0.04f);
glVertex2f(0.43f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.43f,-0.14f);
glVertex2f(0.43f,-0.17f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.45f,-0.14f);
glVertex2f(0.45f,-0.17f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.45f,-0.14f);
glVertex2f(0.43f,-0.14f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.435f,-0.14f);
glVertex2f(0.435f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.445f,-0.14f);
glVertex2f(0.445f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,-0.03f);
glVertex2f(0.93f,-0.03f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,-0.06f);
glVertex2f(0.93f,-0.06f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,-0.09f);
glVertex2f(0.93f,-0.09f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,-0.12f);
glVertex2f(0.93f,-0.12f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,-0.15f);
glVertex2f(0.93f,-0.15f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,-0.18f);
glVertex2f(0.93f,-0.18f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,-0.21f);
glVertex2f(0.93f,-0.21f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.7f,-0.03f);
glVertex2f(0.72f,-0.03f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.7f,-0.06f);
glVertex2f(0.72f,-0.06f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.7f,-0.09f);
glVertex2f(0.72f,-0.09f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.7f,-0.12f);
glVertex2f(0.72f,-0.12f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.7f,-0.15f);
glVertex2f(0.72f,-0.15f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.7f,-0.18f);
glVertex2f(0.72f,-0.18f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.7f,-0.21f);
glVertex2f(0.72f,-0.21f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.28f,0.4f);
glVertex2f(0.28f,0.1f);
glVertex2f(0.24f,0.1f);
glVertex2f(0.24f,0.4f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.28f,0.1f);
glVertex2f(0.28f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.28f,0.1f);
glVertex2f(0.28f,0.4f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.27f,0.1f);
glVertex2f(0.27f,0.38f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.25f,0.1f);
glVertex2f(0.25f,0.38f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.24f,0.4f);
glVertex2f(0.28f,0.4f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.25f,0.38f);
glVertex2f(0.27f,0.38f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.98f,0.33f);
glVertex2f(0.98f,0.3f);
glVertex2f(0.28f,0.3f);
glVertex2f(0.28f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.98f,0.33f);
glVertex2f(0.98f,0.3f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.98f,0.3f);
glVertex2f(0.28f,0.3f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.28f,0.3f);
glVertex2f(0.28f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.98f,0.33f);
glVertex2f(0.28f,0.33f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.96f,0.3f);
glVertex2f(0.96f,0.27f);
glVertex2f(0.65f,0.27f);
glVertex2f(0.65f,0.3f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.96f,0.3f);
glVertex2f(0.96f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.96f,0.27f);
glVertex2f(0.65f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.65f,0.27f);
glVertex2f(0.65f,0.3f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.96f,0.3f);
glVertex2f(0.65f,0.3f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.65f,0.3f);
glVertex2f(0.65f,0.1f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.95f,0.27f);
glVertex2f(0.95f,0.24f);
glVertex2f(0.92f,0.24f);
glVertex2f(0.92f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,0.27f);
glVertex2f(0.95f,0.24f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,0.24f);
glVertex2f(0.92f,0.24f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.92f,0.24f);
glVertex2f(0.92f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,0.27f);
glVertex2f(0.92f,0.27f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.95f,0.08f);
glVertex2f(0.95f,0.05f);
glVertex2f(0.92f,0.05f);
glVertex2f(0.92f,0.08f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,0.08f);
glVertex2f(0.95f,0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,0.05f);
glVertex2f(0.92f,0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.92f,0.05f);
glVertex2f(0.92f,0.08f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.95f,0.08f);
glVertex2f(0.92f,0.08f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.942f,0.24f);
glVertex2f(0.942f,0.08f);
glVertex2f(0.928f,0.08f);
glVertex2f(0.928f,0.24f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.942f,0.24f);
glVertex2f(0.942f,0.08f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.928f,0.08f);
glVertex2f(0.928f,0.24f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.78f,0.08f);
glVertex2f(0.78f,0.05f);
glVertex2f(0.81f,0.05f);
glVertex2f(0.81f,0.08f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.78f,0.08f);
glVertex2f(0.78f,0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.78f,0.05f);
glVertex2f(0.81f,0.05f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.81f,0.05f);
glVertex2f(0.81f,0.08f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.78f,0.08f);
glVertex2f(0.81f,0.08f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.81f,0.27f);
glVertex2f(0.81f,0.24f);
glVertex2f(0.78f,0.24f);
glVertex2f(0.78f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.81f,0.27f);
glVertex2f(0.81f,0.24f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.81f,0.24f);
glVertex2f(0.78f,0.24f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.78f,0.24f);
glVertex2f(0.78f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.81f,0.27f);
glVertex2f(0.78f,0.27f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.805f,0.24f);
glVertex2f(0.805f,0.08f);
glVertex2f(0.787f,0.08f);
glVertex2f(0.787f,0.24f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.805f,0.24f);
glVertex2f(0.805f,0.08f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.787f,0.08f);
glVertex2f(0.787f,0.24f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.63f,0.3f);
glVertex2f(0.63f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.6f,0.3f);
glVertex2f(0.6f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.63f,0.27f);
glVertex2f(0.6f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.63f,0.13f);
glVertex2f(0.63f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.6f,0.13f);
glVertex2f(0.6f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.6f,0.13f);
glVertex2f(0.63f,0.13f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.625f,0.13f);
glVertex2f(0.625f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.61f,0.13f);
glVertex2f(0.61f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.5f,0.3f);
glVertex2f(0.5f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.47f,0.3f);
glVertex2f(0.47f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.5f,0.27f);
glVertex2f(0.47f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.5f,0.13f);
glVertex2f(0.5f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.47f,0.13f);
glVertex2f(0.47f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.5f,0.13f);
glVertex2f(0.47f,0.13f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.495f,0.13f);
glVertex2f(0.495f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.48f,0.13f);
glVertex2f(0.48f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.31f,0.3f);
glVertex2f(0.31f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.34f,0.3f);
glVertex2f(0.34f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.31f,0.27f);
glVertex2f(0.34f,0.27f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.31f,0.1f);
glVertex2f(0.31f,0.13f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.34f,0.1f);
glVertex2f(0.34f,0.13f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.31f,0.13f);
glVertex2f(0.34f,0.13f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.315f,0.27f);
glVertex2f(0.315f,0.13f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.335f,0.27f);
glVertex2f(0.335f,0.13f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.96f,0.45f);
glVertex2f(0.96f,0.33f);
glVertex2f(0.91f,0.33f);
glVertex2f(0.91f,0.45f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.96f,0.45f);
glVertex2f(0.96f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.96f,0.33f);
glVertex2f(0.91f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.91f,0.33f);
glVertex2f(0.91f,0.45f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.96f,0.45f);
glVertex2f(0.91f,0.45f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.7f,0.45f);
glVertex2f(0.7f,0.33f);
glVertex2f(0.65f,0.33f);
glVertex2f(0.65f,0.45f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.7f,0.45f);
glVertex2f(0.7f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.7f,0.33f);
glVertex2f(0.65f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.65f,0.33f);
glVertex2f(0.65f,0.45f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.7f,0.45f);
glVertex2f(0.65f,0.45f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.91f,0.42f);
glVertex2f(0.91f,0.33f);
glVertex2f(0.7f,0.33f);
glVertex2f(0.7f,0.42f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.91f,0.42f);
glVertex2f(0.91f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.91f,0.33f);
glVertex2f(0.7f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.7f,0.33f);
glVertex2f(0.7f,0.42f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.91f,0.42f);
glVertex2f(0.7f,0.42f);
glEnd();

glBegin(GL_TRIANGLES);
glColor3ub(255, 172, 117);
glVertex2f(0.805f,0.5f);
glVertex2f(0.88f,0.42f);
glVertex2f(0.73f,0.42f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.805f,0.5f);
glVertex2f(0.88f,0.42f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.805f,0.5f);
glVertex2f(0.73f,0.42f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.805f,0.47f);
glVertex2f(0.85f,0.42f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.805f,0.47f);
glVertex2f(0.76f,0.42f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.935f,0.48f);
glVertex2f(0.935f,0.45f);
glEnd();

glBegin(GL_TRIANGLES);//building light
glColor3ub(255, 247, 0);
glVertex2f(0.935f,0.53f);
glVertex2f(0.942f,0.48f);
glVertex2f(0.928f,0.48f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.677f,0.48f);
glVertex2f(0.677f,0.45f);
glEnd();

glBegin(GL_TRIANGLES);//building light
glColor3ub(255, 247, 0);
glVertex2f(0.676f,0.53f);
glVertex2f(0.684f,0.48f);
glVertex2f(0.669f,0.48f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(0.65f,0.36f);
glVertex2f(0.65f,0.33f);
glVertex2f(0.28f,0.33f);
glVertex2f(0.28f,0.36f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.65f,0.36f);
glVertex2f(0.65f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.65f,0.33f);
glVertex2f(0.28f,0.33f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.28f,0.33f);
glVertex2f(0.28f,0.36f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.65f,0.36f);
glVertex2f(0.28f,0.36f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.95f,0.43f);
glVertex2f(0.95f,0.35f);
glVertex2f(0.92f,0.35f);
glVertex2f(0.92f,0.43f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.69f,0.43f);
glVertex2f(0.69f,0.35f);
glVertex2f(0.66f,0.35f);
glVertex2f(0.66f,0.43f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.88f,0.41f);
glVertex2f(0.88f,0.34f);
glVertex2f(0.85f,0.34f);
glVertex2f(0.85f,0.41f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.82f,0.41f);
glVertex2f(0.82f,0.34f);
glVertex2f(0.79f,0.34f);
glVertex2f(0.79f,0.41f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.76f,0.41f);
glVertex2f(0.76f,0.34f);
glVertex2f(0.73f,0.34f);
glVertex2f(0.73f,0.41f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.9f,0.25f);
glVertex2f(0.9f,0.23f);
glVertex2f(0.84f,0.23f);
glVertex2f(0.84f,0.25f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.89f,0.21f);
glVertex2f(0.89f,0.13f);
glVertex2f(0.85f,0.13f);
glVertex2f(0.85f,0.21f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.76f,0.25f);
glVertex2f(0.76f,0.23f);
glVertex2f(0.68f,0.23f);
glVertex2f(0.68f,0.25f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.74f,0.21f);
glVertex2f(0.74f,0.13f);
glVertex2f(0.7f,0.13f);
glVertex2f(0.7f,0.21f);
glEnd();


glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.9f,-0.1f);
glVertex2f(0.9f,-0.25f);
glVertex2f(0.87f,-0.25f);
glVertex2f(0.87f,-0.1f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.78f,-0.1f);
glVertex2f(0.78f,-0.25f);
glVertex2f(0.75f,-0.25f);
glVertex2f(0.75f,-0.1f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.64f,-0.01f);
glVertex2f(0.64f,-0.17f);
glVertex2f(0.61f,-0.17f);
glVertex2f(0.61f,-0.01f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.52f,-0.01f);
glVertex2f(0.52f,-0.17f);
glVertex2f(0.49f,-0.17f);
glVertex2f(0.49f,-0.01f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.39f,-0.01f);
glVertex2f(0.39f,-0.17f);
glVertex2f(0.36f,-0.17f);
glVertex2f(0.36f,-0.01f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.57f,0.23f);
glVertex2f(0.57f,0.1f);
glVertex2f(0.54f,0.1f);
glVertex2f(0.54f,0.23f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.43f,0.23f);
glVertex2f(0.43f,0.1f);
glVertex2f(0.4f,0.1f);
glVertex2f(0.4f,0.23f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.23f,0.11f);
glVertex2f(-0.32f,-0.28f);
glVertex2f(-0.31f,-0.32f);
glVertex2f(-0.22f,0.1f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(-0.32f,-0.28f);
glVertex2f(-0.34f,-0.28f);
glVertex2f(-0.34f,-0.32f);
glVertex2f(-0.31f,-0.32f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.23f,0.11f);
glVertex2f(0.32f,-0.28f);
glVertex2f(0.31f,-0.32f);
glVertex2f(0.22f,0.1f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(135, 81, 19);
glVertex2f(0.32f,-0.28f);
glVertex2f(0.34f,-0.28f);
glVertex2f(0.34f,-0.32f);
glVertex2f(0.31f,-0.32f);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 172, 117);
glVertex2f(-0.22f,0.1f);
glVertex2f(-0.31f,-0.32f);
glVertex2f(0.31f,-0.32f);
glVertex2f(0.22f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.22f,0.1f);
glVertex2f(0.22f,0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.225f,0.08f);
glVertex2f(0.225f,0.08f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.23f,0.06f);
glVertex2f(0.23f,0.06f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.235f,0.04f);
glVertex2f(0.235f,0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.24f,0.02f);
glVertex2f(0.24f,0.02f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.245f,0.0f);
glVertex2f(0.245f,0.0f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.25f,-0.02f);
glVertex2f(0.25f,-0.02f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.255f,-0.04f);
glVertex2f(0.255f,-0.04f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.26f,-0.06f);
glVertex2f(0.26f,-0.06f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.265f,-0.08f);
glVertex2f(0.265f,-0.08f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.27f,-0.1f);
glVertex2f(0.27f,-0.1f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.275f,-0.12f);
glVertex2f(0.275f,-0.12f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.28f,-0.14f);
glVertex2f(0.28f,-0.14f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.284f,-0.16f);
glVertex2f(0.284f,-0.16f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.288f,-0.18f);
glVertex2f(0.288f,-0.18f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.291f,-0.2f);
glVertex2f(0.291f,-0.2f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.295f,-0.22f);
glVertex2f(0.295f,-0.22f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.299f,-0.24f);
glVertex2f(0.299f,-0.24f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.31f,-0.26f);
glVertex2f(0.31f,-0.26f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.314f,-0.28f);
glVertex2f(0.314f,-0.28f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.318f,-0.3f);
glVertex2f(0.318f,-0.3f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-0.32f,-0.315f);
glVertex2f(0.32f,-0.315f);
glEnd();



















	glFlush();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("Test");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display1);
	glutMainLoop();
	return 0;
}

